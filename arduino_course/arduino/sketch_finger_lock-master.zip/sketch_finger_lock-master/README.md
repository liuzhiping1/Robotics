sketch_finger_lock
==================

demo of fingerprint lock
